<?php require_once '../../../config/connection.php';?>
<?php require_once '../../../config/staff-session-check.php';?>
<?php
if (!$checkBasicSecurity){/// start if 1
    goto end;
}
if(!$checkSession){
	$response['response']=99;
	$response['success']=false;
	$response['message']="SESSION EXPIRED! Please LogIn Again.";
	goto end;
}
    //////////////////declaration of variables//////////////////////////////////////
    $session=$_GET['session'];
    $termId=$_GET['termId'];
    $branchId = $_GET['branchId'];
    $departmentId = $_GET['departmentId'];
    $classId = $_GET['classId'];

    if (empty($branchId)){/// start if 2
        $response = [
            'response'=> 100,
            'success'=> false,
            'message'=> "BRANCH REQUIRED! Check the fields and try again",
        ]; 
        goto end;
	}
    if (empty($session)){/// start if 2
        $response = [
            'response'=> 100,
            'success'=> false,
            'message'=> "SESSION REQUIRED! Check the fields and try again",
        ]; 
        goto end;
	}
        if (empty($termId)){/// start if 2
        $response = [
            'response'=> 100,
            'success'=> false,
            'message'=> "TERM REQUIRED! Check the fields and try again",
        ]; 
        goto end;
	}
    if (empty($departmentId)){/// start if 2
        $response = [
            'response'=> 100,
            'success'=> false,
            'message'=> "DEPARTMENT iD REQUIRED! Check the fields and try again",
        ]; 
        goto end;
	}
    if (empty($classId)){/// start if 2
        $response = [
            'response'=> 100,
            'success'=> false,
            'message'=> "CLASS ID REQUIRED! Check the fields and try again",
        ]; 
        goto end;
	}


    /////////////////// for  $termId
    $termDataQuery = mysqli_query($conn, "SELECT termId, termName AS currentTerm FROM SETUP_TERM_TAB WHERE termId='$termId'");
    $termDataFetch = mysqli_fetch_assoc($termDataQuery);

    /////////////////// for  $branchId
    $branchDataQuery = mysqli_query($conn, "SELECT name AS branchName, schoolLogo, address, smtpUsername, mobileNumber, session AS currentSession, termName FROM BRANCH_VIEW WHERE $clientIds AND branchId='$branchId'");
    $branchDataFetch = mysqli_fetch_assoc($branchDataQuery);

    /////////////////// for  $departmentId
    $departmentDataQuery = mysqli_query($conn, "SELECT departmentId, departmentName FROM DEPARTMENTS_TAB WHERE $clientIds AND departmentId='$departmentId'");
    $departmentDataFetch = mysqli_fetch_assoc($departmentDataQuery);
    

    /////////////////// for  $classId
    $classDataQuery = mysqli_query($conn, "SELECT classId, className FROM CLASSES_TAB WHERE $clientIds AND classId='$classId'");
    $classDataFetch = mysqli_fetch_assoc($classDataQuery);
    


    $select = "SELECT * FROM FEES_SETTINGS_TAB WHERE $clientIds AND branchId='$branchId'";
    $query=mysqli_query($conn,$select)or die (mysqli_error($conn));
    $allRecordCount=mysqli_num_rows($query);
    if($allRecordCount==0){///start if 1
        $response['response']=200;
        $response['success']=false;
        $response['message']="No Record found";
        $response['currentSession'] = $session;
        $response['termData'] = $termDataFetch;
        $response['branchData'] = $branchDataFetch;
        $response['departmentData'] = $departmentDataFetch;
        $response['classData'] = $classDataFetch;
        goto end;
    }


    $response['response']=200; 
    $response['success']=true;
    $response['message']="FEES FETCH SUCCESFFULY!";
    $response['allRecordCount']=$allRecordCount;
    $response['currentSession'] = $session;
    $response['termData'] = $termDataFetch;
    $response['branchData'] = $branchDataFetch;
    $response['departmentData'] = $departmentDataFetch;
    $response['classData'] = $classDataFetch;
    $response['data'] = array(); // Initialize the data array

    while ($fetchQuery = mysqli_fetch_assoc($query)) {
        $feesId=$fetchQuery['feesId'];
        /////////////////// for  $feesId
        $feesDataQuery = mysqli_query($conn, "SELECT amount FROM FEES_COMPUTE_TAB WHERE $clientIds AND branchId='$branchId' AND session='$session' AND termId='$termId' AND departmentId='$departmentId' AND classId='$classId' AND feesId='$feesId'");
        $feesDataFetch = mysqli_fetch_assoc($feesDataQuery);
        $fetchQuery['amount'] = $feesDataFetch['amount'] ?? '';

        $response['data'][] = $fetchQuery;
    }
//////////////////////////////////////////////////////////////////////////////////////////////
end:
echo json_encode($response);
?>