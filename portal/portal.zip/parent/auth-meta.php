<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="ROBOTS" content="ALL">
<meta name="Engine" content="all">
<meta name="distribution" content="global">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="<?php echo $websiteUrl ?>/images/icon.png" rel="shortcut icon" type="image-png" />
<link href="<?php echo $websiteUrl ?>/style/icons-1.11.3/font/bootstrap-icons.css" type="text/css" rel="stylesheet">
<link href="<?php echo $websiteUrl ?>/style/animate.css" type="text/css" rel="stylesheet" media="all">
<link href="<?php echo $websiteUrl ?>/style/aos.css" type="text/css" rel="stylesheet" />
<link href="<?php echo $websiteUrl ?>/style/paramount.css?v=<?php echo $codeVersion ?>" type="text/css"
    rel="stylesheet" />
<link href="<?php echo $websiteUrl ?>/style/parent/auth-style.css?v=<?php echo $codeVersion ?>" type="text/css"
    rel="stylesheet" />
<link href="<?php echo $websiteUrl ?>/style/parent/main-style.css?v=<?php echo $codeVersion ?>" type="text/css"
    rel="stylesheet" />

<script src="<?php echo $websiteUrl ?>/js/jquery-v3.6.1.min.js"></script>
<script src="<?php echo $websiteUrl ?>/js/paramount.js?v=<?php echo $codeVersion ?>"></script>
<script src="<?php echo $websiteUrl ?>/js/parent/useAuth.js?v=<?php echo $codeVersion ?>"></script>
<script src="<?php echo $websiteUrl ?>/js/parent/usePortalResult.js?v=<?php echo $codeVersion ?>"></script>
<script src="<?php echo $websiteUrl ?>/js/parent/usePortalPayment.js?v=<?php echo $codeVersion ?>"></script>
<script src="<?php echo $websiteUrl ?>/js/textfield-selectfield.js?v=<?php echo $codeVersion ?>"></script>

<script>
    let parentSessionData = JSON.parse(sessionStorage.getItem("parentSessionData"));

    if (parentSessionData) {
        window.parent.location.href = parentPortalUrl;
    } else {
        sessionStorage.clear();
    }
</script>